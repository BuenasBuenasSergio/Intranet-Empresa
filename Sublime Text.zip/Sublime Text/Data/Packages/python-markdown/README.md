# sublime-markdown

Sublime dependency for Python Markdown

Current version: 2.6.11

# License

https://github.com/facelessuser/sublime-markdown/blob/master/st3/LICENSE.md
